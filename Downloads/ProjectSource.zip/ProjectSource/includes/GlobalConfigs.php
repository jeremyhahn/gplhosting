<?php 
/*
 YOU SHOULD NOT CHANGE ANYTHING IN THIS CONFIGURATION FILE!
 This file is modified best by using the Administration link while being logged in as a site admin!
*/
/* APACHE 2.0 CONFIGURATION */
// This Apache 2.0 configuration was last updated by the control panel on 07-10-04 by Jeremy
$Apache2 = "/Apache/,/Apache/logs/,/usr/local/apache2/conf/httpd.conf,192.168.xxx.xxx,/etc/init.d/httpd graceful,/usr/sbin/rotatelogs,5M,1,1";
$IntApacheStatSpider = "12 hours";
$ApacheCustDirectives = "LogFormat \"%h %l %u %t \\\"%r\\\" %>s %b \\\"%{Referer}i\\\" \\\"%{User-Agent}i\\\"\" combined";
/* END APACHE 2.0 CONFIGURATION */
/* XMAIL CONFIGURATION */
// This XMail configuration was last updated by the control panel on 07-06-04 by Jeremy
$Xmail = "192.168.xxx.xxx,6017,admin,15041616120a1701,/var/MailRoot";
/* END XMAIL CONFIGURATION */
/* WEBALIZER CONFIGURATION */
// This Webalizer configuration was last updated by the control panel on 07-03-04 by Jeremy
$WebalizerConf = "PageType,htm*\r\n";
$WebalizerConf .= "PageType,php*\r\n";
$WebalizerConf .= "DNSChildren,10\r\n";
$WebalizerConf .= "Quiet,yes\r\n";
$WebalizerConf .= "HideURL,*.gif\r\n";
$WebalizerConf .= "HideURL,*.GIF\r\n";
$WebalizerConf .= "HideURL,*.jpg\r\n";
$WebalizerConf .= "HideURL,*.JPG\r\n";
$WebalizerConf .= "HideURL,*.png\r\n";
$WebalizerConf .= "HideURL,*.PNG\r\n";
$WebalizerConf .= "HideURL,*.ra\r\n";
$WebalizerConf .= "SearchEngine,yahoo.com,p=\r\n";
$WebalizerConf .= "SearchEngine,altavista.com,q=\r\n";
$WebalizerConf .= "SearchEngine,google.com,q=\r\n";
$WebalizerConf .= "SearchEngine,eureka.com,q=\r\n";
$WebalizerConf .= "SearchEngine,lycos.com,query=\r\n";
$WebalizerConf .= "SearchEngine,hotbot.com,MT=\r\n";
$WebalizerConf .= "SearchEngine,msn.com,MT=\r\n";
$WebalizerConf .= "SearchEngine,infoseek.com,qt=\r\n";
$WebalizerConf .= "SearchEngine,webcrawler,searchText=\r\n";
$WebalizerConf .= "SearchEngine,excite,search=\r\n";
$WebalizerConf .= "SearchEngine,netscape.com,search=\r\n";
$WebalizerConf .= "SearchEngine,mamma.com,query=\r\n";
$WebalizerConf .= "SearchEngine,alltheweb.com,query=\r\n";
$WebalizerConf .= "SearchEngine,northernlight.com,qr=";
$WebalizerHome = "/etc/webalizer";
/* END WEBALIZER CONFIGURATION */
/* BIND CONFIGURATION */
// This BIND configuration was last updated by the control panel on 07-03-04 by Jeremy
$BIND = "/etc/named.conf,/var/named/,/usr/sbin/rndc";
/* END BIND CONFIGURATION *//* SITE CONFIGURATION */
// This site configuration was last updated by the control panel on 07-06-04 by Jeremy
$ThirdLevelDomains = "cyberdataengineering.com,gplhosting.org,mycorporatewebsite.com,pc-technics.com";
$ExternalWAN_IP = "xxx.xxx.xxx.xxx";
$SudoPassword = "";
$HomeServer = "gplhosting.org";
$CoLoServers = "192.168.xxx.xxx,192.168.xxx.xxx";
$UseSSL = "1";
/* END SITE CONFIGURATION */
/* MEMBER CONFIGURATION */
// These membership settings were last updated by the control panel on 07-06-04 by Jeremy
$MemberPlans = "Site Admin,0,1,0,20480,0,0,0,0,0,0,0,0.00\r\n";
$MemberPlans .= "Guest,5,1,5,2048,5,5,5,5,5,10485760,104857600,10.00";
/* END MEMBER CONFIGURATION */
?>