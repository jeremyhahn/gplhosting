<HTML>
<HEAD>
<TITLE>Project GPL Hosting</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<link type="text/css" rel="stylesheet" href="style.css">
</HEAD>
<BODY BGCOLOR=#FFFFFF leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#666699">
<table width=780 border=0 cellpadding=0 cellspacing=0 height="383" bgcolor="#FFFFFF">
<?php include("header.html"); ?>
  <tr> 
    <td colspan=3 background="images/links.gif"> 
     <?php include("navigation.html"); ?>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="233"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="10" height="188">
        <tr> 
          <td height="212"><div align="center">
            <p class="BodyHeader">&nbsp;</p>
            <p class="BodyHeader">Help :: Mail Administration</p>
            <p class="menu">The GPL Hosting mail services are very powerful, yet simple to configure! The GPL Hosting network offers standard POP3 mailboxes which can be used with any POP3 Email client, such as Microsoft Outlook, from your home or office. The GPL Hosting network also offers advanced mail solutions such as mail server backup services and Port 25 redirections for those inconsiderate ISP's who don't have confidence in your postal skills. Our network also offers SMART SERVER configurations for your mail server which is on a dynamic IP block, who is being prohibited from relaying to the big boys who participate in the new anti-spam campaign to help cut down on spam.</p>
            <p>&nbsp;</p>
            <table width="50%" border="0" class="menu">
              <tr>
                <td width="195"><div align="center">
                    <p><a href="HELP_MAIL_Configs.php?Display=POP3"><img src="images/Profile_Email.gif" alt="Get Help With DNS Jargon &amp; Acronyms" width="32" height="32" border="0"></a></p>
                    <p><a href="HELP_MAIL_Configs.php?Display=POP3">POP3 Mailboxes</a></p>
                </div></td>
                <td width="177"><div align="center">
                    <p><a href="HELP_MAIL_Configs.php?Display=MX"><img src="images/Help/MX_Backup.jpg" alt="Get Help With DNS Configurations" width="32" height="32" border="0"></a></p>
                    <p><a href="HELP_MAIL_Configs.php?Display=MX">MX Backup</a></p>
                </div></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><div align="center">
                  <p><a href="HELP_MAIL_Configs.php?Display=Port25"><img src="images/rj45.jpg" alt="Get Help With DNS Jargon &amp; Acronyms" width="40" height="30" border="0"></a></p>
                  <p><a href="HELP_MAIL_Configs.php?Display=Port25">Port 25 Deflections</a></p>
                </div></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
            </table>
            <p>&nbsp; </p>
          </div></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="14"> 
      <div align="center"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0" height="35" align="center">
          <tr> 
            <td background="images/index_08.gif" height="35"> 
              <?php include("footer.html"); ?>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>
</BODY>
</HTML>