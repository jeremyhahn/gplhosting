<HTML>
<HEAD>
<TITLE>Project GPL Hosting</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<link type="text/css" rel="stylesheet" href="style.css">
<style type="text/css">
.style2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style3 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.style5 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bold;
	font-style: italic;
}
</style>
</HEAD>
<BODY BGCOLOR=#FFFFFF leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#666699">
<table width=780 border=0 cellpadding=0 cellspacing=0 height="383" bgcolor="#FFFFFF">
<?php include("header.html"); ?>
  <tr> 
    <td colspan=3 background="images/links.gif"> 
     <?php include("navigation.html"); ?>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="233"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="10" height="188">
        <tr> 
          <td height="212"><p class="style2">&nbsp;</p>
            <p class="style2">Thanks To Everyone Who Assists In The Project! </p>
            <p class="style2">&nbsp;</p>
            <table width="75%" border="1" align="center" bordercolor="#F9F9F9" class="menu">
              <tr>
                <td width="37%"><span class="style5">Contributor</span></td>
                <td width="63%"><span class="style5">Donation</span></td>
              </tr>
              <tr>
                <td><span class="style3"><a href="http://www.jeremy.pc-technics.com" target="_blank">Jeremy Hahn </a></span></td>
                <td><span class="style3">Founder of Project GPL Hosting</span></td>
              </tr>
              <tr>
                <td><span class="style3"><a href="http://jghpcpro.com" target="_blank">JGHPCPRO</a></span></td>
                <td><span class="style3">Redundant Network Link </span></td>
              </tr>
              <tr>
                <td><span class="style3"><a href="http://www.aletek.com" target="_blank">Aletek Solutions </a></span></td>
                <td><span class="style3">Online Website Builder - (Coming Soon!) </span></td>
              </tr>
            </table>            
            <p class="style3">&nbsp;</p>
            <p class="style3">&nbsp;</p>
          <p class="style3">Many thanks to those who have contributed to the project. Please continue to get involved and help support the worlds most educational and functional free hosting network!</p>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="14"> 
      <div align="center"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0" height="35" align="center">
          <tr> 
            <td background="images/index_08.gif" height="35"> 
              <?php include("footer.html"); ?>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>
</BODY>
</HTML>