<HTML>
<HEAD>
<TITLE>Project GPL Hosting</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<link type="text/css" rel="stylesheet" href="style.css">
</HEAD>
<BODY BGCOLOR=#FFFFFF leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#666699">
<table width=780 border=0 cellpadding=0 cellspacing=0 height="383" bgcolor="#FFFFFF">
<?php include("header.html"); ?>
  <tr> 
    <td colspan=3 background="images/links.gif"> 
     <?php include("navigation.html"); ?>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="233"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="10" height="188">
        <tr> 
          <td height="212"><div align="center">
            <p class="BodyHeader">&nbsp;</p>
            <p class="BodyHeader">HELP TOPICS </p>
            <p class="menu">Are you stuck with a configuration and in need of some assistance? Choose a topic below to search through the FAQ. </p>
            <p>&nbsp;</p>
            <table width="58%" border="0" class="menu">
              <tr>
                <td width="227"><div align="center">
                  <p><a href="HELP_DNS.php"><img src="images/Help/BigDNS.gif" alt="Get Help With DNS Administration" width="32" height="32" border="0"></a></p>
                  <p><a href="HELP_DNS.php">DNS Administration</a> </p>
                </div></td>
                <td width="206"><div align="center">
                  <p><a href="HELP_MAIL.php"><img src="images/Profile_Email.gif" alt="Get Help With Mail Administration" width="32" height="32" border="0"></a></p>
                  <p><a href="HELP_MAIL.php">Mail Administration </a></p>
                </div></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><p align="center"><a href="HELP_Web.php"><img src="images/Help/web.gif" alt="Get Help With Web Administration" width="32" height="32" border="0"></a></p>
                  <p align="center"><a href="HELP_Web.php">Website Administration</a> </p></td>
                <td><div align="center">
                  <p><a href="HELP_FTP.php"><img src="images/Help/FTP.gif" alt="Get Help With FTP Administration" width="32" height="32" border="0"></a></p>
                  <p><a href="HELP_FTP.php">FTP Administration </a></p>
                </div></td>
              </tr>
            </table>
            <p>&nbsp; </p>
          </div></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="14"> 
      <div align="center"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0" height="35" align="center">
          <tr> 
            <td background="images/index_08.gif" height="35"> 
              <?php include("footer.html"); ?>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>
</BODY>
</HTML>