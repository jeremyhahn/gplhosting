' #############################################
' #                                           #
' #     Copyright 2003 Pc Technics, Inc.      #
' #                                           #
' #       Update Client Web Interface         #
' #                                           #
' #         Written By: Jeremy Hahn           #
' #                                           #
' #############################################
 
 ' This is 'free' software with the following restrictions:
'
' You may not redistribute this code as a 'sample' or 'demo'. However, you are free
' to use the source code in your own code, but you may not claim that you created
' the sample code. It is expressly forbidden to sell or profit from this source code
' other than by the knowledge gained or the enhanced value added by your own code.
'
' Use of this software is also done so at your own risk. The code is supplied as
' is without warranty or guarantee of any kind.



' This is a very simple ASP interface which is meant to demonstrate the power which the dynamic update client
' is capable of delivering. Its datbase backend allows for sophisticated and highly advanced configurations
' which allows third party applications or services to seemlessly integrate with its functionality. Our goal was to build a
' reliable non-proprietary client which would seemlessly integrate with your existing network, while providing you with fault 
' tolerance and consistent operation.


' Please NOTE that this interface should not be rolled out as a fully functional commercial interface. The error trapping in
' this interface is very poor, and does not take everything inconsideration all of the issues which could be introduced in a
' 'real' working environment. This interface is provided only as an EXAMPLE or a foundation which you can add your own code,
' to complete the interface. This website is very basic, which should make customization a snap. Your feedback is welcome at 
' feedback@pc-technics.com. You may also visit our community newsgroups at news://news.pc-technics.com. We hope you are 
' enjoying our services!            



'Contact Us For A Custom Quote If You Are Interested In Your Own Personal Interface Which Meets Specific Requirements.


'                                                                   - Pc Technics, Inc.

' ##########################################################################################################################

This software is provided 'AS IS' and not offer ANY warranties. By using this software, you are agreeing that you are using
this application at your own risk.



If you are interested in a customized version of this script, please contact us for details. This script was offered as an
incentive for developers to persue a version of their own, should they feel inclined to do so. This was meant to provide
a foundation on which you can build on. This interface is very simple, and highly customizable. Please contact us if you need
any assistance.



 **** PLEASE NOTE THE CONFIG.ASP FILE WHICH MUST BE CONFIGURED PROPERLY IF WANT THIS SCRIPT TO WORK !!! ****
 