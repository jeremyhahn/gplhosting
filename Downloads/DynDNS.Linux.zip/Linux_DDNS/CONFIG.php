<?php
/* 

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.








   ------------------------------------------------------------------------
   These are the main configuration variables for the update script. Please
   check your spelling!
   
                                        (c) Copyright CyberData Engineering
                                                       Code By: Jeremy Hahn 
   ------------------------------------------------------------------------
   
   
 
LOGGING: 
  If set to 'ON', the service will send visual alerts to the console. Any other 
  value than 'ON', and you will have to check the log file at /path/to/ddns/ddns.log
  to check the status on dynamic updates. If this log file gets too full, you may
  archive/delete it. The script will start a new file by itself.
  
*/   
$Logging = "ON";  # Great for a BETA version ;-P


/*

AUTHENTICATION:
  This is the username and password that you log into GPL-Hosting with.
  
  GPL-Hosting uses MD5 Encryption. Since this requires additional libraries
  to be compiled, we left the decision up to you. If you need a hash generator, you
  are welcome to use our online generator at 
  http://www.gplhosting.org/SiteTools/md5.php
  
  You can also download a VB.exe program at http://www.frez.co.uk/freecode.htm#md5
 
*/
$Username = "YOUR_USERNAME"; 
$Password = "89914c28cf6e9c7b8dd12aa666e3"; // GPL-Hosting_Rocks!


/*
POLL INTERVAL:
   This is the specified time (in seconds) which the update service will check 
   your public IP to verify that it is up to date. 
*/
$UpdateInterval = 1800; #Seconds 



/*
ZONE CONFIGURATION:
   It starts to get a little confusing here. Here we have an array which contains
   each of your FQDN's (Fully Qualified Domain Names), however, it is broken down
   into 'Hostname' , 'Domain' Arrays here.
	   
	If you have multiple hostnames, but one domain, your configuration would be ...
	
	 $Host = array("Host1","Host2","Host3","Host4");
     $Domain = array("Domain1.com","Domain1.com","Domain1.com","Domain1.com");
	
	Which would result in the following FQDN's
	
	   Host1.Domain1.com
	   Host2.Domain1.com
	   Host3.Domain1.com
	   Host4.Domain1.com
	
   
   Here is a sample where each host belongs to its own domain. 
   
     $Host = array("Host1","Host2","Host3","Host4");
     $Domain = array("Domain1.com","Domain2.com","Domain3.com","Domain4.com");

   The above configuration would update the following Fully Qualified Domain Names
	 
	   Host1.Domain1.com
	   Host2.Domain2.com
	   Host3.Domain3.com
	   Host4.Domain4.com

   
   * NOTE: If you have added host records to a third level domain such as 
           you.gplhosting.org, where you now have host1.host2.you.gplhosting.org,
		   your hostname would be host1.host2 , while your domain would be you.gplhosting.org.
		   Although this is not technically correct, the information had to be stored in our
		   database in a logical fashion. This structure allowed us to do so.
		   
		  * The above would result in host1.host2 being the hostname, and the domain would 
		    be you.gplhosting.org. The FQDN would be host1.host2.you.gplhosting.org
			
			$Host = array("host1.host2");
			$Domain = array("you.gplhosting.org");
			
			
   You can use as many domains as you want here, but just follow the ARRAY() rules! 
*/
# Would give us 2 domains ...
# host1.gplhosting.org
# host2.gplhosting.org
$Host = array("host1","host2");
$Domain = array("gplhosting.org","gplhosting.org");





/*
   This is not mandatory if you are using this software personally, however, 
   If you redistribute this program, THE ENTIRE CONTENTS OF THIS PACKAGE
   MUST REMAIN INTACT, WITH ALL COPYRIGHT NOTIFICATIONS, and WITHOUT 
   MODIFICATION OF ANY KIND!
*/   
$AppVersion = "Dynamic Update Client v1.0 (Linux)";
$AppCopyright = "(c) Copyright 2004 CyberData Engineering\r\nCode By: Jeremy Hahn";
?>