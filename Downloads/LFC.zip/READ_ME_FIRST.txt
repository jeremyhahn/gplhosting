THIS PROGRAM IS RELEASED AS A FREEWARE DOWNLOAD FROM PC TECHNICS 

www.pc-technics.com




The Linksys Failover Client (LFC) acts as both a network monitor and an automatic update 

client for BEFSR41, BEFSR11, and BEFSRU31 series routers. LFC can be configured to monitor 

primary HTTP, FTP, DNS, SMTP, and POP3 protocols on your private network. If a protocol 

stops responding (most likely due to failure), LFC will log into your router and make the 

necessary update to redirect traffic to a functional failover server on your private network.

LFC runs as an NT service, and has been tested on 2000 pro & server, XP, and 2003 server.



--- IMPORTANT ---

 LFC updates the Upnp Port Forwarding page in the router. This version only has support for 

HTTP, FTP, DNS, POP3, and SMTP. IF YOU ARE USING ANY OTHER PORT CONFIGURATION ON THIS PAGE,

LFC WILL OVERWRITE THESE SETTINGS WHEN A FAILOVER UPDATE IS INITIATED !!!!!!!!!!!!!!!!!!!!!

This will be a permanent limitation of this version of the software, however, if I get

constructive feedback, I may release a commercial version between $10 and $20 which will have

support for custom configurations also. I also have been thinking about building an alternative

web interface, due to linksys neglect of supporting an HTTPS secure remote connection to the router

for remote management :-(  ...... Lets hope Cisco picks up the slack ... :-D


-----------------------------------------------------------------------------------------------------





If you have any questions or comments, please visit our online community at www.forums.pc-technics.com

so that everyone can benefit from your questions, comments, or concerns.






DISCLAIMER:



              IF LFC fries your CPU, singes your motherboard, or shoots a floppy out of your drive which
then hits you in the knee, and makes you spill hot coffee all over your new pants, YOU ARE USING THIS 
SOFTWARE AT YOUR OWN RISK!!!!!!!! Please post your experiences at our forum. 




ENJOY !!! :-D


-----------------------------------------------------------------------------------------------------------


- Jeremy Hahn

  Currently Seeking Employment!
  
  www.jeremy.pc-technics.com