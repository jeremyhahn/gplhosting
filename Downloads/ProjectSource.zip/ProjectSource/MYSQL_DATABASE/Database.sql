/* 
GPL Hosting Database Structure & Base Configs
Copyright 2004 Jeremy Hahn
*/

create database if not exists `GPL_Source_DB`;

use `GPL_Source_DB`;

/*
Table structure for Clients
*/

drop table if exists `Clients`;
CREATE TABLE `Clients` (
  `Username` varchar(255) default NULL,
  `Email` varchar(255) NOT NULL default '',
  `Plan` varchar(255) default NULL,
  `HomeServer` text,
  `Created` date default NULL,
  `LastLogin` date default NULL,
  `LastLoginIP` varchar(255) default NULL,
  `Password` varchar(255) default NULL,
  `SecretPhrase` varchar(255) default NULL,
  `SignupIP` varchar(255) default NULL,
  PRIMARY KEY  (`Email`)
) TYPE=MyISAM;

/*
Table data for YOUR_DB_NAME.Clients
*/

INSERT INTO `Clients` VALUES 
('admin','root@localhost','Site Admin','localhost','0000-00-00','0000-00-00','192.168.2.11','5f4dcc3b5aa765d61d8327deb882cf99','5f4dcc3b5aa765d61d8327deb882cf99','192.168.2.200');

/*
Table structure for Comments
*/

drop table if exists `Comments`;
CREATE TABLE `Comments` (
  `Date` date default NULL,
  `Username` varchar(255) default NULL,
  `Comment` text,
  `SiteRep` varchar(255) default NULL,
  `VisibleToClient` int(1) default NULL,
  `UniqueID` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`UniqueID`)
) TYPE=MyISAM;

/*
Table structure for DNS_Records
*/

drop table if exists `DNS_Records`;
CREATE TABLE `DNS_Records` (
  `Username` varchar(50) default NULL,
  `Hostname` varchar(255) default NULL,
  `RecType` varchar(5) default NULL,
  `Alias` varchar(255) default NULL,
  `RecData` varchar(255) default 'N/A',
  `MX_Pref` int(255) default '0',
  `RecID` bigint(255) NOT NULL auto_increment,
  `ZoneID` bigint(255) default '0',
  PRIMARY KEY  (`RecID`)
) TYPE=MyISAM;

/*
Table structure for DNS_Zones
*/

drop table if exists `DNS_Zones`;
CREATE TABLE `DNS_Zones` (
  `ZoneID` bigint(255) NOT NULL auto_increment,
  `Username` varchar(255) default NULL,
  `Zone` varchar(255) default NULL,
  `Type` varchar(255) default 'master',
  `PS` varchar(255) default NULL,
  `RP` text,
  `Serial` bigint(255) default NULL,
  `Refresh` bigint(255) default NULL,
  `Retry` bigint(255) default NULL,
  `Expire` bigint(255) default NULL,
  `TTL` bigint(255) default NULL,
  PRIMARY KEY  (`ZoneID`)
) TYPE=MyISAM;

/*
Table structure for DynDNS_Stats
*/

drop table if exists `DynDNS_Stats`;
CREATE TABLE `DynDNS_Stats` (
  `Username` varchar(255) default NULL,
  `Date` varchar(255) default NULL,
  `FromIP` varchar(255) default NULL,
  `Response` blob,
  `FQDN` varchar(255) default NULL,
  `UniqueID` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`UniqueID`)
) TYPE=MyISAM;

/*
Table structure for FTP_Records
*/

drop table if exists `FTP_Records`;
CREATE TABLE `FTP_Records` (
  `Username` varchar(250) NOT NULL default '',
  `Password` varchar(255) default NULL,
  `Owner` varchar(255) default NULL,
  `DaRoot` tinyint(1) default NULL,
  `Website` varchar(255) default NULL,
  `Unique_ID` varchar(250) NOT NULL default '',
  PRIMARY KEY  (`Username`,`Unique_ID`)
) TYPE=MyISAM;

/*
Table structure for Globals
*/

drop table if exists `Globals`;
CREATE TABLE `Globals` (
  `Variable` varchar(255) NOT NULL default '',
  `Value` blob,
  `Enabled` tinyint(1) default '0',
  PRIMARY KEY  (`Variable`)
) TYPE=MyISAM;

/*
Table data for GPL_Source_DB.Globals
*/

INSERT INTO `Globals` VALUES 
('BIND','/etc/named.conf,/var/named/,/usr/sbin/rndc',1),
('ThirdLevelDomains','cyberdataengineering.com,gplhosting.org,mycorporatewebsite.com,pc-technics.com',1),
('Xmail','192.168.xxx.xxx,6017,admin,15041616120a1701,/var/MailRoot',1),
('Apache2.0','/Apache/,/Apache/logs/,/usr/local/apache2/conf/httpd.conf,192.168.xxx.xxx,/etc/init.d/httpd graceful,/usr/sbin/rotatelogs,5M,1,1',1),
('ApacheCustDirectives','LogFormat \"%h %l %u %t \\\"%r\\\" %>s %b \\\"%{Referer}i\\\" \\\"%{User-Agent}i\\\"\" combined',1),
('WebalizerConf','PageType,htm*\r\nPageType,php*\r\nDNSChildren,10\r\nQuiet,yes\r\nHideURL,*.gif\r\nHideURL,*.GIF\r\nHideURL,*.jpg\r\nHideURL,*.JPG\r\nHideURL,*.png\r\nHideURL,*.PNG\r\nHideURL,*.ra\r\nSearchEngine,yahoo.com,p=\r\nSearchEngine,altavista.com,q=\r\nSearchEngine,google.com,q=\r\nSearchEngine,eureka.com,q=\r\nSearchEngine,lycos.com,query=\r\nSearchEngine,hotbot.com,MT=\r\nSearchEngine,msn.com,MT=\r\nSearchEngine,infoseek.com,qt=\r\nSearchEngine,webcrawler,searchText=\r\nSearchEngine,excite,search=\r\nSearchEngine,netscape.com,search=\r\nSearchEngine,mamma.com,query=\r\nSearchEngine,alltheweb.com,query=\r\nSearchEngine,northernlight.com,qr=',1),
('WebalizerHome','/etc/webalizer',1),
('SudoPassword','',1),
('ExternalWAN_IP','xxx.xxx.xxx.xxx',1),
('MemberPlans','Site Admin,0,1,0,20480,0,0,0,0,0,0,0,0.00\r\nGuest,5,1,5,2048,5,5,5,5,5,10485760,104857600,10.00',1),
('Serverlocations','192.168.xxx.xxx,192.168.xxx.xxx',0),
('HomeServer','localhost',0),
('IntApacheStatSpider','12 hours',0),
('UseSSL','0',0);

/*
Table structure for HTTP_Records
*/

drop table if exists `HTTP_Records`;
CREATE TABLE `HTTP_Records` (
  `Username` varchar(255) default NULL,
  `DocumentRoot` text,
  `NameVhost` varchar(255) default NULL,
  `ServerName` varchar(255) NOT NULL default '',
  `ServerAlias` text,
  `ServerAdmin` text,
  `LogFile` text,
  `DiskQuota` bigint(255) default '10485760',
  `BandwidthQuota` bigint(255) default NULL,
  PRIMARY KEY  (`ServerName`)
) TYPE=MyISAM;

/*
Table structure for MAIL_Domains
*/

drop table if exists `MAIL_Domains`;
CREATE TABLE `MAIL_Domains` (
  `ZoneID` bigint(255) NOT NULL auto_increment,
  `Username` varchar(255) default NULL,
  `MailDomain` varchar(255) default NULL,
  `Quota` varchar(255) default NULL,
  `Type` varchar(255) default NULL,
  PRIMARY KEY  (`ZoneID`)
) TYPE=MyISAM;

/*
Table structure for MAIL_Records
*/

drop table if exists `MAIL_Records`;
CREATE TABLE `MAIL_Records` (
  `Username` varchar(255) default NULL,
  `Password` varchar(255) default '',
  `Mailbox` varchar(255) default '',
  `Quota` varchar(255) default '',
  `RedirectTo` varchar(255) default NULL,
  `MailboxID` bigint(255) NOT NULL auto_increment,
  `Type` varchar(255) default NULL,
  `ZoneID` bigint(255) default NULL,
  PRIMARY KEY  (`MailboxID`)
) TYPE=MyISAM;

/*
Table structure for PaymentLog
*/

drop table if exists `PaymentLog`;
CREATE TABLE `PaymentLog` (
  `Date` date default NULL,
  `Username` varchar(255) default NULL,
  `Plan` varchar(255) default NULL,
  `PaidAmount` varchar(255) default NULL,
  `InCollections` varchar(255) default NULL,
  `Overdue` int(1) default NULL,
  `Credits` varchar(255) default NULL,
  `UniqueID` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`UniqueID`)
) TYPE=MyISAM;

/*
Table structure for PaymentSummary
*/

drop table if exists `PaymentSummary`;
CREATE TABLE `PaymentSummary` (
  `Date` date default NULL,
  `Username` varchar(255) default NULL,
  `Plan` varchar(255) default NULL,
  `PaidAmount` varchar(255) default NULL,
  `InCollections` varchar(255) default NULL,
  `Overdue` int(1) default NULL,
  `Credits` varchar(255) default NULL,
  `UniqueID` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`UniqueID`)
) TYPE=MyISAM;

/*
Table structure for Pending_Activations
*/

drop table if exists `Pending_Activations`;
CREATE TABLE `Pending_Activations` (
  `Username` varchar(255) NOT NULL default '',
  `Password` varchar(255) default NULL,
  `Email` varchar(255) default NULL,
  `SecretPhrase` varchar(255) default NULL,
  `IP` varchar(255) default NULL,
  `UniqueID` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`UniqueID`)
) TYPE=MyISAM;

