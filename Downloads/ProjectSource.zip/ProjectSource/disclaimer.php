<HTML>
<HEAD>
<TITLE>Project GPL Hosting</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<link type="text/css" rel="stylesheet" href="style.css">
<style type="text/css">
.style3 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 12px;
	color: #FF0000;
}
.style4 {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.style5 {font-size: 12px}
</style>
</HEAD>
<BODY BGCOLOR=#FFFFFF leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#666699">
<table width=780 border=0 cellpadding=0 cellspacing=0 height="383" bgcolor="#FFFFFF">
<?php include("header.html"); ?>
  <tr> 
    <td colspan=3 background="images/links.gif"> 
     <?php include("navigation.html"); ?>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="233"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="10" height="188">
        <tr> 
          <td height="212"><p align="center" class="style3">&nbsp;</p>
            <p align="center" class="style3">By using any of our free online services, you are hereby stating that you have agreed to each of the following terms. Failure to comply with these regulations could result in anything from severe legal penalties to earning a top ranking on our black-list. Please respect these services as well as the entire GPL Hosting community with the respect it deserves. </p>
            <p align="center" class="style3">&nbsp;</p>            <ul>
              <li><span class="style4"><strong> This network program is being released under the <a href="http://www.gnu.org/copyleft/gpl.html" target="_blank">GNU Public Licence Agreement</a>.</strong></span></li>
              </ul>
            <ul>
              <li><span class="style4"><strong>We DO NOT offer free internet hosting for others to profit from! If we catch on to any suspicious activity which leads us to believe you are using our community to STEAL from our corporation, reputation or hard earned work, an investigation will be issued, and you WILL be prosecuted against to fullest extent of the law. <strong>Project GPL Hosting</strong> is owned by Jeremy Hahn, and I reserve all rights to royalties, honor, and recognition for the hard work which I put into the development of these services. Please give  this community the credit which it deserves, and do not steal from it! EVERY DNS domain, Mail domain, port deflection domain, and EVERY other domain which is hosted by Project GPL Hosting server equipment MUST RESOLVE TO YOUR ISP. If we find that you are hosting accounts which do NOT resolve to YOUR ISP, you will be permanently banned from our community. If someone you know is in need of our services, please pass the word along. The success of the project relies on generous donations and advertisement of profitable services. </strong></span></li>
            </ul>
            <p align="center" class="style5">
            <ul class="style5">
              <li>
                <p align="center"><span class="style4"><strong>By using this FREE network program, you are using an 'AS IS' service. WE DO NOT GUARANTEE ANY UPTIME AT ALL! This project is intended for educational and marketing purposes only! This network will be maintained 24/7 just as any other network, however, in today's law suit happy environment, this was necessary to state in this disclaimer. We did not hack into your server using some DNS magic, and we did not crash your server which has had 12 years of uptime. We did not make you sign up, and we certainly do not need to be sued for offering a free service/program!<a href="http://www.no-ip.com"></a></strong></span></p>
              </li>
            </ul>
            <p align="center" class="style5">
            <ul>
              <li>
                <p align="center"><span class="style4"><strong>We reserve the right to ban anyone we wish from this site. If we detect any activity which perturbs us in any way, we will NOT hesitate to permanently ban you from our network. (This means you spammer!) There are some who benefit from this project, and  we would appreciate your cooperation in return for providing the solutions which we do. If you feel the need to compromise system security, or hack another users account after looking at the website source code, then please sign up with our project security team, and assist us in coming up with solutions that the entire community can benefit from.</strong></span></p>
              </li>
            </ul></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="14"> 
      <div align="center"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0" height="35" align="center">
          <tr> 
            <td background="images/index_08.gif" height="35"> 
              <?php include("footer.html"); ?>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>
</BODY>
</HTML>