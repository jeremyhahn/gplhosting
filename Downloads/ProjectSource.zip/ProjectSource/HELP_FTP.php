<HTML>
<HEAD>
<TITLE>Project GPL Hosting</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<link type="text/css" rel="stylesheet" href="style.css">
</HEAD>
<BODY BGCOLOR=#FFFFFF leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#666699">
<table width=780 border=0 cellpadding=0 cellspacing=0 height="383" bgcolor="#FFFFFF">
<?php include("header.html"); ?>
  <tr> 
    <td colspan=3 background="images/links.gif"> 
     <?php include("navigation.html"); ?>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="233"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="10" height="188">
        <tr> 
          <td height="212"><p align="center" class="BodyHeader">&nbsp;</p>
            <p align="center" class="BodyHeader">Help :: File Transfer Protocol (FTP) Administration</p>
            <p align="center" class="menu">The GPL Hosting network allows access to your website hierarchy using the FTP protocol. You can add multiple users to any website directory, including the root directory for your home folder. Before you can begin using the FTP functions, you must first create a website. </p>
            <p align="center" class="menu">&nbsp;</p>
            <p><span class="BodyHeader">Adding A New FTP User </span><br>
                <span class="menu">To add a new FTP user, simply point to FTP Hosting in the control panel, and then click on 'New FTP Login' from the submenu that rolls out. Once at the form used to create the new user, enter the username and password for the new user (numerical characters not allowed for first character), and then select which website you want this user to be able to access. Please be advised that by giving someone root level access to your web account is not recommended, as they have the power to completely wipe out your entire directory structure. Usually this type of access is only given only to trusted people, or used to create a 'backdoor' to your website directories. </span></p>
            <p>&nbsp;</p>
            <p><span class="BodyHeader">Deleting  An FTP User</span><br>
              <span class="menu">To delete an FTP user, simply click on the trash bin next to the users name that you want to delete. After confirming the delete dialog box, your FTP user will be removed from the system. </span></p>
            <p>&nbsp;</p>
            <p><span class="BodyHeader">Resetting an FTP Users Password </span><br>
              <span class="menu">FTP passwords are not to be confused with website login passwords. FTP users can NOT gain access to the website at all, ONLY the websites which you specify. To reset an FTP users password, click on the lock next to the users name. The next page will display 4 textboxes which will allow you to update ONLY the password for the user. The username and website of the specified user will be displayed in a read-only format. Please be advised that by deleting the account holders FTP credentials, you will be wiping out EVERY FTP user, and ALL websites that are under the account holders home folder. Only delete the acount holders FTP login if you are done using the web/ftp services. </span></p>
          <p>&nbsp;</p>
          <p align="center"><a href="HELP.php" class="menu">Return To Main Help Menu</a></p>
          <p>&nbsp;</p></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="14"> 
      <div align="center"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0" height="35" align="center">
          <tr> 
            <td background="images/index_08.gif" height="35"> 
              <?php include("footer.html"); ?>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>
</BODY>
</HTML>