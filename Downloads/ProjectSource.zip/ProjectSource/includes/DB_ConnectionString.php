<?php

$username = "YOUR_MYSQL_USERNAME";
$password = "YOUR_MYSQL_PASSWORD";
$hostname = "192.168.xxx.xxx";
$db_name = "YOUR_MYSQL_DB_NAME";

$db = mysql_connect($hostname, $username, $password) 
	or die("Unable to connect to the database server. Please report this problem to support@gplhosting.org.");
	
	
	$selectedDB = mysql_select_db($db_name,$db) 
		or die("Could not find the database on the server.");
?>