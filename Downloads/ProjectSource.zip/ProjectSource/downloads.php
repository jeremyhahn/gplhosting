<HTML>
<HEAD>
<TITLE>Project GPL Hosting</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<link type="text/css" rel="stylesheet" href="style.css">
<style type="text/css">
<!--
.style2 {color: #FF0000}
-->
</style>
</HEAD>
<BODY BGCOLOR=#FFFFFF leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#666699">
<table width=780 border=0 cellpadding=0 cellspacing=0 height="383" bgcolor="#FFFFFF">
<?php include("header.html"); ?>
  <tr> 
    <td colspan=3 background="images/links.gif"> 
     <?php include("navigation.html"); ?>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="233"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="10" height="188">
        <tr> 
          <td height="212"><p class="BodyHeader">&nbsp;</p>
            <p class="menu"><span class="BodyHeader">Project GPL Hosting Source </span></p>
            <p class="menu">If you are looking for the  complete Project source code package, please click <a href="source.php">here</a>. </p>            
            <hr>
            <p>&nbsp;</p>
            <p class="BodyHeader">Dynamic DNS Client </p>
            <p class="menu">The dynamic DNS client works with our Domain Name System (DNS) server, to update your A-Record IP address. The dynamic DNS client is useful for users who want to host thier own servers using a dynamic IP address. You can read more on dynamic DNS <a href="HELP_DNS_UpdateClient.php">here</a>. If you are interested in a dynamic DNS client that supports multiple dynamic DNS services, you are welcome to check out <a href="http://noeld.com/dynsite.asp" target="_blank">DynSite</a>, by <a href="http://noeld.com" target="_blank">Noel Danjou</a>. </p>
            <p class="menu">Current Version :: 1.0</p>
            <p class="menu"><a href="Downloads/DynDNS.Win32.zip">Download</a> - For Windows Platform </p>
            <p class="menu"><a href="Downloads/DynDNS.Linux.zip">Download</a> - For Linux Platform </p>            <p class="menu">&nbsp;</p>
            <p class="BodyHeader">Dynamic DNS Client Web Interface </p>
            <p class="menu">Current Version :: 1.0</p>
            <p class="menu">This is a sample web interface which works with the dynamic DNS client for the Windows version only. Since the dynamic DNS client is database driven, it can be controlled and configured in just about any type of environment. This sample web interface was written in ASP. </p>            
            <p class="menu"><a href="Downloads/DUCWeb.zip">Download</a></p>
            <hr>
            <p class="menu">&nbsp;</p>            <p class="menu"><span class="BodyHeader">Linksys Failover Client </span></p>
          <p class="menu"> The Linksys Failover Client (LFC) acts as both a network monitor and an automatic update client for Linksys routers. LFC can be configured to monitor primary HTTP, FTP, DNS, SMTP, and POP3 protocols on your private network. If a protocol stops responding (most likely due to failure) , LFC will log into your router and make the necessary update to redirect traffic to a functional failover server on your private network. LFC runs as an NT service, and has been tested on 2000 Pro &amp; Server, XP, and 2003 Server. </p>
          <p class="menu style2">FREEWARE!</p>
          <p class="menu"><a href="Downloads/LFC.zip">Download</a></p>
          <p class="menu">&nbsp;</p></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="14"> 
      <div align="center"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0" height="35" align="center">
          <tr> 
            <td background="images/index_08.gif" height="35"> 
              <?php include("footer.html"); ?>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>
</BODY>
</HTML>