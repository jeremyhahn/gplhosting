<?php
/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/



# There is nothing to configure in this file, however, 
# feel free to have a look around!

# (c) Copyright 2004 CyberData Engineering
# Designed By: Jeremy Hahn 

require("CONFIG.php");

function Timer($CurrentTime,$UpdateInterval)
{
	if ($CurrentTime < $CurrentTime + $UpdateInterval)
	{
	  sleep($UpdateInterval);
	  PerformUpdate($UpdateInterval);   
	}

}


function PerformUpdate($Interval)
{

// Read The Response From The LAST XML File
	$LastXML = fopen ("LastIP.xml", "r"); 
	 
	
	  while (!feof($LastXML)) 
	  {
		$Lastbuffer = fgets($LastXML, 4096);
		
		$LastResponse .= $Lastbuffer;
	  }
  
   
	 
		  // Parse The LAST XML File To Get The Current Public IP Address
		  $LastIPstart = strpos($LastResponse,"<WANaddress value=\"") + 19;
		  $LastIPend = strpos($LastResponse,"</WANaddress>") - 2;		  
		    
			$Lastlength = ($LastIPstart - $LastIPend);		
		
		  $LastIP = substr($LastResponse,$LastIPstart,-$Lastlength);  
		  
		 
		  
		             
					 // Parse The LAST XML File To Get The TimeStamp Of Last Poll { if applicable }
					 $LastTimeStampStart = strpos($LastResponse,"<TimeStamp value=\"") + 18;
		             $LastTimeStampEnd = strpos($LastResponse,"</TimeStamp>") -2;		  
		    
			            $LastTSlength = ($LastTimeStampStart - $TLastimeStampEnd);		
		
		             $LastTimeStamp = substr($LastResponse,$LastTimeStampStart,-$LastTSlength);

 fclose($LastXML);





// Get The CURRENT IP Address { Formatted As XML! }
$ch = curl_init ("http://www.gplhosting.org/XMLip.php");
$fp = fopen ("CurrentIP.xml", "w");

 curl_setopt ($ch, CURLOPT_FILE, $fp);
 curl_exec ($ch);
 curl_close ($ch);

fclose ($fp);



	// Read The Response From The CURRENT XML File
	$XML = fopen ("CurrentIP.xml", "r");
	
	while (!feof($XML)) 
	  {
		$buffer = fgets($XML, 4096);
		
		$Response .= $buffer;
	  }
	  
    
     
		  // Parse The CURRENT XML File To Get The Current Public IP Address
		  $IPstart = strpos($Response,"<WANaddress value=\"") + 19;
		  $IPend = strpos($Response,"</WANaddress>") - 2;		  
		    
			$length = ($IPstart - $IPend);		
		
		  $CurrentIP = substr($Response,$IPstart,-$length);  
		  
		 
		  
		             
					 // Parse The CURRENT XML File To Get The TimeStamp Of Last Poll { if applicable }
					 $TimeStampStart = strpos($Response,"<TimeStamp value=\"") + 18;
		             $TimeStampEnd = strpos($Response,"</TimeStamp>") -2;		  
		    
			            $TSlength = ($TimeStampStart - $TimeStampEnd);		
		
		             $TimeStamp = substr($Response,$TimeStampStart,-$TSlength);





// We Have All The Info We Need .......
fclose($XML);



				 if ($LastIP == $CurrentIP)
				 {
				   // We Take No Action, Because The Public IP Hasn't Changed...
				 }
				 else
				    {
					 // Creates A File We Can Use To Compare IP's On The Next Poll...
                      if (!(copy("CurrentIP.xml","LastIP.xml")))
					  {
					  echo "\r\n" . $AppVersion . "\r\n";
                      echo "\r\n\r\nConsole Message From $AppVersion\r\n\r\n";
					  echo "Couldn't copy XML file.. Please verify permissions.\r\n";
					  }
					  sleep(1);
					     // Calls The Dynamic DNS Update Function
						 DoDynamicUpdate($CurrentIP);
						 
					}
					
										
		// Now We Reset The Timer To The Specified UpdateInterval
		Timer(time(),$Interval);

					
}




// The Function That Does The Actual DNS Update
function DoDynamicUpdate($IP)
{
global $AppVersion;
global $AppCopyright;
global $Username;
global $Password;
global $Host;
global $Domain;
global $Logging;
 
 if ($Logging == "ON")
 {
  echo "\r\n" . $AppVersion . "\r\n";
  echo "\r\n\r\nConsole Message From $AppVersion\r\n\r\nYour Public IP Has Changed.\r\nYour new address is $IP.\r\n\r\n";
 }
 
   $Num_Hosts = count($Host);
   $Num_Domains = count($Domain);


    
	
// Update Each Configured FQDN in CONFIG.php ARRAY
  for ($Key=0; $Key < $Num_Hosts; $Key++)
  {
     if ($Logging == "ON")
     {
		  if (!(empty($Host[$Key])))
		   {
			 // This is a domain with a hostname
			   echo "Updating " . $Host[$Key] . "." . $Domain[$Key] . "\r\n";
	       }
		   else
			  {
			   // This is a top level domain, with no hostname
               echo "Updating " . $Domain[$Key] . "\r\n"; 			  
			  }
	 }
     
	 
	 if (isset($Host[$Key]))
	 {
	 $UpdateString = "http://www.gplhosting.org/API/dynupdate.asp?Username="
	                . $Username . "&Password=" . $Password . "&Hostname=" . $Host[$Key] . "&Domain="
					. $Domain[$Key] . "&IP=" . $IP;
     }
	 else
	     {
		  $UpdateString = "http://www.gplhosting.org/API/dynupdate.asp?Username="
	                . $Username . "&Password=" . $Password . "&Hostname=@&Domain="
					. $Domain[$Key] . "&IP=" . $IP;

		 }
		
    
     $HTTPexec = curl_init ($UpdateString);
     $logfile = fopen ("ddns.log", "w");
	 
                   curl_setopt ($HTTPexec, CURLOPT_FILE, $logfile);
                   curl_exec ($HTTPexec);          
	               curl_close ($HTTPexec);
	            
				fclose ($logfile);
   }
                
    echo "\r\n" . $AppCopyright . "\r\n";
}


// This call executes the main function when service.php is loaded
PerformUpdate($UpdateInterval)  	
?>
