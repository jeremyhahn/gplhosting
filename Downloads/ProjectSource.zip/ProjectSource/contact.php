<HTML>
<HEAD>
<TITLE>Project GPL Hosting</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<link type="text/css" rel="stylesheet" href="style.css">
<style type="text/css">
.style2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style3 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.style5 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; }
</style>
</HEAD>
<BODY BGCOLOR=#FFFFFF leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#666699">
<table width=780 border=0 cellpadding=0 cellspacing=0 height="383" bgcolor="#FFFFFF">
<?php include("header.html"); ?>
  <tr> 
    <td colspan=3 background="images/links.gif"> 
     <?php include("navigation.html"); ?>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="233"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="10" height="188">
        <tr> 
          <td height="212"><p align="center" class="style2">&nbsp;</p>
            <p align="left" class="style2">Contact Information:</p>
            <p align="left" class="style3"> Each service has been delegated to its respective department. Please contact the proper department for your concern. Please also be sure to include any details which we may need to efficiently process your request. </p>
            <p align="left" class="style3">&nbsp;</p>
            <p align="left"><span class="style5">General: </span><br>
              <span class="style3">
			  <a href="mailto:abuse@gplhosting.org">Abuse</a><br>
			  <a href="mailto:feedback@gplhosting.org">Feedback</a><br>
              <a href="mailto:contributors@gplhosting.org">Contributors</a><br>
              <a href="mailto:support@gplhosting.org">Technical Support</a><br>
              <a href="mailto:webmaster@gplhosting.org">Webmaster</a></span></p>
            <p align="left" class="style3">&nbsp;</p></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td colspan=3 height="14"> 
      <div align="center"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0" height="35" align="center">
          <tr> 
            <td background="images/index_08.gif" height="35"> 
              <?php include("footer.html"); ?>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>
</BODY>
</HTML>